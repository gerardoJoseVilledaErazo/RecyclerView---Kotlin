package com.example.recyclerview_example.models

data class Contacto(var nombreContacto: String,
                    var numeroTelefonico: Int) {
}